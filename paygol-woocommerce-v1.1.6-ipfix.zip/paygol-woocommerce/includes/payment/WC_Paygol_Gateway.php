<?php

namespace Paygol\PaygolWoocommerce\includes\payment;

use WC_Payment_Gateway;
use Paygol\PaygolCore\PaygolApi;
use Paygol\PaygolCore\Models\Payer;
use Paygol\PaygolCore\Models\RedirectUrls;
use Paygol\PaygolCore\EnvironmentEnum;

// Translation: https://www.flippercode.com/make-a-wordpress-plugin-multilingual/
// https://github.com/vslavik/poedit
class WC_Paygol_Gateway extends WC_Payment_Gateway
{
    const PGID_REQUEST = 'PGID';
    const STATUS_REQUEST = 'status';
    const CUSTOM_REQUEST = 'custom';
    const KEY_REQUEST = 'key';

    const PLUGIN_ID = 'paygol';
    const API_HOOK_PREFIX = 'woocommerce_api_';
    const CONFIRMATION_API_NAME = 'confirmation_' . self::PLUGIN_ID;
    const API_HOOK_CONFIRMATION_KEY = self::API_HOOK_PREFIX . self::CONFIRMATION_API_NAME;
    const API_HOOK_UPDATE_OPTIONS = 'woocommerce_update_options_payment_gateways_' . self::PLUGIN_ID;

    public $token_service;
    public $token_secret;
    public $environment;

    public $confirmation_url;

    public function __construct()
    {
        $this->id = self::PLUGIN_ID; // Payment gateway plugin ID
        $this->icon = $this->get_icon(); // Icon that will be displayed on checkout page near your gateway name
        $this->has_fields = false; // In case you need a custom credit card form
        $this->method_title = 'Paygol.com';
        $this->method_description = __(
            'Activa Paygol y permite a tus clientes pagar con los principales métodos de pago en Chile y Latinoamérica.',
            'paygol-woocommerce'
        ); // Will be displayed on the options page

        $this->notify_url = add_query_arg('wc-api', 'WC_Gateway_' . $this->id, home_url('/'));

        // Options supported by the gateway (subscriptions, refunds, saved payment, etc). This plugin support simple payments only.
        $this->supports = ['products'];

        // Load the settings.
        $this->init_form_fields();
        $this->init_settings();

        // Set plugin variables
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');

        $this->token_service = $this->get_option('token_service');
        $this->token_secret = $this->get_option('token_secret');
        $this->environment = $this->get_option('enviroment');
        $this->debug_mode = $this->get_option('debug_mode');
        $this->send_new_orders_email = $this->get_option('send_new_orders_email');

        // Hook for save plugins options
        add_action(self::API_HOOK_UPDATE_OPTIONS, [$this, 'process_admin_options']);

        // Hook for payment confirmation
        add_action(self::API_HOOK_CONFIRMATION_KEY, [$this, 'api_hook_confirmation']);

        // Paygol IPN
        add_action('woocommerce_api_wc_gateway_' . $this->id, array($this, 'check_ipn_response'));

        // Get confirmation url
        $this->confirmation_url = WC()->api_request_url(self::CONFIRMATION_API_NAME);
    }

    /**
     * Plugin options
     */
    public function init_form_fields()
    {
        $this->form_fields = [
            'enabled' => [
                'title' => __('Activar', 'paygol-woocommerce'),
                'type' => 'checkbox',
                'label' => __('Activar Paygol pasarela de pagos', 'paygol-woocommerce'),
                'default' => 'yes',
                'desc_tip' => true,
            ],
            'enviroment' => [
                'title' => __('Ambiente', 'paygol-woocommerce'),
                'type' => 'select',
                'label' => __('Seleccionar ambiente', 'paygol-woocommerce'),
                'description' => __('Indicar el ambiente en que se procesarás los pagos.', 'paygol-woocommerce'),
                'default' => EnvironmentEnum::DEVELOPMENT,
                'options' => [
                    EnvironmentEnum::PRODUCTION => 'Producción',
                    EnvironmentEnum::DEVELOPMENT => 'Desarrollo',
                ],
                'desc_tip' => true,
            ],
            'title' => [
                'title' => __('Título', 'paygol-woocommerce'),
                'type' => 'text',
                'description' => __('Este es el título que el usuario verá en la pantalla el pago.', 'paygol-woocommerce'),
                'default' => __('Paygol SpA.', 'paygol-woocommerce'),
            ],
            'description' => [
                'title' => __('Descripción', 'paygol-woocommerce'),
                'type' => 'textarea',
                'description' => __('Descripción del método de pago que el cliente verá en la pantalla de pago.', 'paygol-woocommerce'),
                'default' => __(
                    'Con Paygol puedes pagar con los principales métodos de pago en Chile y Latinoamérica.',
                    'paygol-woocommerce'
                ),
                'desc_tip' => true,
            ],
            'token_service' => [
                'title' => __('ID de servicio', 'paygol-woocommerce'),
                'type' => 'text',
                'description' => __('Tus credenciales de integración las puedes obtener ingresando al portal de clientes de Paygol en https://secure.paygol.com', 'paygol-woocommerce'),
                'desc_tip' => true,
            ],
            'token_secret' => [
                'title' => __('Shared secret', 'paygol-woocommerce'),
                'type' => 'text',
                'description' => __('Tus credenciales de integración las puedes obtener ingresando al portal de clientes de Paygol en https://secure.paygol.com', 'paygol-woocommerce'),
                'desc_tip' => true,
            ],
            'redirect' => [
                'title' => __('Redirección', 'paygol-woocommerce'),
                'type' => 'checkbox',
                'label' => __('Redirección automática', 'paygol-woocommerce'),
                'default' => 'yes',
            ],
            'debug_mode' => [
                'title' => __('Debug', 'paygol-woocommerce'),
                'type' => 'checkbox',
                'label' => __('Activar logs', 'paygol-woocommerce'),
                'default' => 'no',
            ],
            'send_new_orders_email' => [
                'title' => __('Email', 'paygol-woocommerce'),
                'type' => 'checkbox',
                'label' => __('Notificar nuevas órdenes', 'paygol-woocommerce'),
                'default' => 'no',
            ],
        ];
    }

    /**
     * Check for Khipu IPN Response
     */
    public function check_ipn_response()
    {
        try {
            http_response_code(400);

            $content_json  = file_get_contents('php://input');
            $payload = json_decode($content_json, true);

            ksort($payload);

            // Get headers
            $headers = getallheaders();

            $signature = $this->computeSignature(json_encode($payload, JSON_PRESERVE_ZERO_FRACTION), $this->token_secret);

            // Check data integrity
            if (empty($headers['X-Pg-Sig']) || $headers['X-Pg-Sig'] !== $signature) {
                $this->plugin_log('Error al validar la firma del mensaje');

                $this->plugin_log('Server signature: ' . ($headers['X-Pg-Sig'] ?? 'Empty'));
                $this->plugin_log('WooCommerce calculated signature: ' . $signature);
                exit('Error al validar la firma del mensaje');
            }

            $orderId = sanitize_text_field(($payload['custom'] ?? ''));
            $paygolTransactionId = sanitize_text_field(($payload['transaction_id'] ?? ''));
            $paygolStatus = sanitize_text_field(($payload['status'] ?? ''));

            // Payment with error or was cancelled
            if ($paygolStatus !== 'completed') {
                $this->plugin_log('Estado de la transacción no es completed: ' . $paygolStatus);
                exit('Estado de la transacción no es completed: ' . $paygolStatus);
            }

            if (!$this->checkStatus($paygolTransactionId)) {
                $this->plugin_log('Error al validar el estado de la transacción');
                exit('Error al validar el estado de la transacción');
            }

            http_response_code(204);

            // The order is marked as completed
            $order = wc_get_order($orderId);

            $order->update_status('completed');

            $this->notifyNewOrders($orderId);
        } catch (\Exception $e) {
            $this->plugin_log($e->getMessage());

            exit($e->getMessage());
        }

        exit();
    }

    /*
     * We're processing the payments here
     */
    public function process_payment($orderId)
    {
        $paymentOptionSelected = $_POST['paygol_payment_option'];

        // Show a error message if payment method isn't selected
        if (!$paymentOptionSelected) {
            $this->displayError('Debe seleccionar un medio de pago para poder continuar.');

            return [
                'result' => 'error',
            ];
        }

        return $this->generateTransaction($orderId, $paymentOptionSelected);
    }

    private function generateTransaction($orderId, $paymentOptionSelected)
    {
        try {
            // Order info
            $order = wc_get_order($orderId);
            $total = (float) round($order->get_total());
            $shop_country = !empty($order->get_billing_country()) ? $order->get_billing_country() : 'CL';

            // Init Paygol Core
            $paygol = new PaygolApi($this->token_service, $this->token_secret, $this->environment);

            // Redirections info
            $redirectUrls = new RedirectUrls();
            $transaction_completed_url = $this->confirmation_url;
            $transaction_canceled_url = $this->confirmation_url;
            $redirectUrls->setRedirects($transaction_completed_url, $transaction_canceled_url);
            $paygol->setRedirects($redirectUrls);

            // Payer Info
            $payer = new Payer();
            $payer->setFirstName($order->get_billing_first_name());
            $payer->setLastName($order->get_billing_last_name());
            $payer->setEmail($order->get_billing_email());
            $payer->setPhoneNumber($order->get_billing_phone());
            $paygol->setPayer($payer);

            // Rest payment info
            $paygol->setCountry($shop_country);
            $paygol->setPrice($total, get_woocommerce_currency());
            $paygol->setPaymentMethod($paymentOptionSelected);
            $paygol->setName('Payment From Paygol');
            $paygol->setCustom($orderId);

            $response = (object) $paygol->createPayment();

            // Selected Payment method url
            if (property_exists((object) $response, 'data')) {
                /**
                 *  Set order with paygol pending payment status
                 */
                $order->update_status('paygol-pending', $response->data['transaction_id']);
                $order->save();
                add_post_meta($orderId, '_paygol_transaction_id', $response->data['transaction_id'], true);

                $redirectUrl = $response->data['payment_method_url'];
                return [
                    'result' => 'success',
                    'redirect' => $redirectUrl,
                ];
            } elseif (property_exists((object) $response, 'error')) {
                // Problem to obtain payment method url.
                $err_msg = 'Ha ocurrido un error, por favor inténtelo nuevamente.';
                $err_dsc = $response->error['message'];
                $this->displayError($err_msg, $err_dsc);
                return [
                    'result' => 'error',
                ];
            }

            $this->displayError(
                'Ha ocurrido un error y no se pudo realizar el pago. Por favor intenta nuevamente. (1)'
            );

            return [
                'result' => 'error',
            ];
        } catch (\Throwable $e) {
            $this->displayError(
                'Ha ocurrido un error y no se pudo realizar el pago. Por favor intenta nuevamente. (2): ' . $e->getMessage()
            );

            return [
                'result' => 'error',
            ];
        }
    }

    private function displayError($message, $description = null)
    {
        $errMsg = '<p>' . $message . '</p>';
        if ($description) {
            $errMsg = $errMsg . '<p>' . $description . '</p>';
        }

        wc_add_notice(__($errMsg, 'paygol-woocommerce'), 'error');
    }

    // Override this method for
    // show all payment methods supported by Paygol
    public function payment_fields()
    {
        // Show Paygol description
        echo '<div style="margin-bottom: 1rem;">' . wpautop(wp_kses_post($this->description)) . '</div>';

        try {
            // Init Paygol Core
            $paygol = new PaygolApi($this->token_service, $this->token_secret, $this->environment);
            $country = WC()->customer->get_shipping_country();
            $paymentMethods = $paygol->getPaymentMethods($country);

            if (property_exists((object) $paymentMethods, 'methods')) {
                // Render payment methods
                include plugin_dir_path(__FILE__) . '../../views/show-payments-methods.php';
            }
        } catch (\Throwable $e) {
            // error_log($e->getMessage());
            echo '<p class="woocommerce-error">' .
                __('Ha ocurrido un error y no se pudo realizar el pago. Por favor intenta nuevamente. (3): ' . $e->getMessage()) .
                '</p>';
        }
    }

    // Validate and confirm payment through Paygol.
    public function api_hook_confirmation()
    {
        $paygolTransactionId = $this->sanitize_url_parameter(self::PGID_REQUEST);
        $paygolStatus = $this->sanitize_url_parameter(self::STATUS_REQUEST);
        $orderIdEncoded = $this->sanitize_url_parameter(self::CUSTOM_REQUEST);
        $signature = $this->sanitize_url_parameter(self::KEY_REQUEST);

        // Request string is not valid
        $isValid = $this->validateRequest($paygolTransactionId, $paygolStatus, $orderIdEncoded, $signature);
        if (!$isValid) {
            $this->displayError('-');
            wp_safe_redirect(wc_get_page_permalink('shop'));
            exit();
        }

        // Decode Order id
        $orderId = $this->base64_url_decode($orderIdEncoded);

        // Payment with error or was cancelled
        if ($paygolStatus !== 'completed') {
            $this->redirectToErrorPage($orderId);
        }

        // Payment Confirmation
        $this->confirmTransacction($paygolTransactionId, $orderId);
    }

    // Method for request validation, based on the hash computation of part the request string.
    private function validateRequest($paygolTransactionId, $paygolStatus, $orderIdEncoded, $signature)
    {
        // Part of the request to be validated
        $query_string =
            self::PGID_REQUEST .
            '=' .
            $paygolTransactionId .
            '&' .
            self::STATUS_REQUEST .
            '=' .
            $paygolStatus .
            '&' .
            self::CUSTOM_REQUEST .
            '=' .
            $orderIdEncoded;

        // Compute signature for comparision
        $computed_signature = $this->computeSignature($query_string, $this->token_secret);

        // Request is valid if both signatures are equals.
        return $computed_signature === $signature;
    }

    private function checkStatus($paygolTransactionId)
    {
        try {
            // Validate payment against Paygol API
            $paygol = new PaygolApi($this->token_service, $this->token_secret, $this->environment);
            $response = $paygol->getPaymentStatus($paygolTransactionId);

            if (property_exists((object) $response, 'payment')) {
                // Successful validation, validate payment status
                if ($response['payment']['status'] === 'completed') {
                    return true;
                }
            }
        } catch (\Exception $e) {
            $this->plugin_log($e->getMessage());
        }

        return false;
    }

    // Method for confirm transaction (payment)
    private function confirmTransacction($paygolTransactionId, $orderId)
    {
        try {
            if (!$this->checkStatus($paygolTransactionId)) {
                die($this->redirectToErrorPage($orderId));
            }

            $this->redirectToSuccessPage($orderId);
        } catch (\Exception $e) {
            $this->redirectToErrorPage($orderId);
        }
    }

    private function redirectToSuccessPage($orderId)
    {
        // The order is marked as completed
        $order = wc_get_order($orderId);

        $order->update_status('completed');

        $this->notifyNewOrders($orderId);

        // Enviar de forma manual correo new order received

        wp_redirect($order->get_checkout_order_received_url());
        exit();
    }

    private function redirectToErrorPage($orderId)
    {
        // The order is marked as failed
        $order = wc_get_order($orderId);
        $order->set_status('failed', '');
        $order->save();

        $this->displayError('Ha ocurrido un error y no se pudo realizar el pago. Por favor intenta nuevamente. (4)');
        wp_safe_redirect($order->get_checkout_payment_url(true));
        exit();
    }

    /**
     * Get Paygol icon
     *
     * @return img tag
     */
    public function get_icon()
    {
        $logo_url = plugins_url('../assets/images/LogoPaygol.png', plugin_dir_path(__FILE__));
        return '<img src="' . $logo_url . '" class="" alt="Paygol SpA. logo." />';
    }

    /**
     * Get Paygol payment option icon
     *
     * @return img tag
     */
    public function get_icon_option($paymentOption)
    {
        // https://cdn.paygol.com/images/logos/164x64/ame.png
        $imgTag = $paymentOption['image_164x64']
            ? '<img src="' . $paymentOption['image_164x64'] . '" alt="' . esc_attr($paymentOption['image_164x64']) . '" class="pg-method-logo" />'
            : '';
        return apply_filters('woocommerce_gateway_icon', $imgTag, $paymentOption['code']);
    }

    private function base64_url_decode($b64text)
    {
        return base64_decode(strtr($b64text, '._-', '+/='));
    }

    private function computeSignature($msg, $secret)
    {
        return hash_hmac('sha256', $msg, $secret);
    }

    private function sanitize_url_parameter($param)
    {
        return isset($_REQUEST[$param]) ? sanitize_text_field($_REQUEST[$param]) : null;
    }

    private function plugin_log($entry, $mode = 'a', $file = 'paygol-woocommerce')
    {
        if ($this->debug_mode !== 'yes') {
            return;
        }

        // Get WordPress uploads directory.
        $upload_dir = wp_upload_dir();
        $upload_dir = $upload_dir['basedir'];

        // If the entry is array, json_encode.
        if (is_array($entry)) {
            $entry = json_encode($entry);
        }

        // Write the log file.
        $file = $upload_dir . '/' . $file . '.log';
        $file = fopen($file, $mode);
        $bytes = fwrite($file, current_time('mysql') . ": " . $entry . "\n");
        fclose($file);
        return $bytes;
    }

    private function notifyNewOrders($orderId)
    {
        if ($this->send_new_orders_email !== 'yes') {
            return;
        }

        $this->plugin_log('Sending email');
        $this->plugin_log($this->send_new_orders_email);

        $email_new_order = WC()->mailer()->get_emails()['WC_Email_New_Order'];

        // Sending the new Order email notification for an $order_id (order ID)
        $email_new_order->trigger($orderId);
    }
}
