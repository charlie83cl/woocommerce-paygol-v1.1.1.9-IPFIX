<?php
//https://rudrastyh.com/woocommerce/payment-gateway-plugin.html
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://paygol.com
 * @since             1.0.0
 * @package           paygol-woocommerce
 *
 * @wordpress-plugin
 * Plugin Name:       Paygol Gateway for WooCommerce
 * Plugin URI:        https://developers.paygol.com#woocommerce
 * Description:       Paga con los principales métodos de pago en Chile y Latinoamérica.
 * Version:           1.1.1n
 * Author:            Paygol
 * Author URI:        https://paygol.com
 * License:           AFL-3.0
 * License URI:       http://opensource.org/licenses/afl-3.0.php
 * Text Domain:       paygol-woocommerce
 * Domain Path:       /languages
 */

namespace Paygol\PaygolWoocommerce;

require_once plugin_dir_path(__FILE__) . 'autoload-lib/autoload.php';

use Paygol\PaygolWoocommerce\includes\payment\WC_Paygol_Gateway;

// If this file is called directly, abort.
if (!defined('WPINC') || !defined('ABSPATH')) {
    die();
}

// Check Woocommerce is installed and enabled
if (!function_exists('is_plugin_active')) {
    require_once ABSPATH . '/wp-admin/includes/plugin.php';
}
if (!is_plugin_active('woocommerce/woocommerce.php')) {
    add_action('admin_notices', function () {
        /* translators: 1. URL link. */
        echo '<div class="error"><p><strong>' .
            sprintf(
                esc_html__(
                    'Paygol Woocommerce plugin requires WooCommerce to be installed and active. You can download %s here.',
                    'paygol-woocommerce'
                ),
                '<a href="https://woocommerce.com/" target="_blank">WooCommerce</a>'
            ) .
            '</strong></p></div>';
    });

    return;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define('PAYGOL_WOOCOMMERCE_VERSION', '1.0.0');

// Actions and filters definitions
add_action('plugins_loaded', 'Paygol\PaygolWoocommerce\init_paygol_gateway');
add_filter('woocommerce_payment_gateways', 'Paygol\PaygolWoocommerce\add_paygol_gateway');
add_action('wp_enqueue_scripts', 'Paygol\PaygolWoocommerce\load_global_scripts_styles');
add_action('init', 'Paygol\PaygolWoocommerce\register_paygol_pending_order_status');
add_filter('wc_order_statuses', 'Paygol\PaygolWoocommerce\add_paygol_pending_to_order_statuses');

// Init Paygol gateway
function init_paygol_gateway()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    class WC_Paygol_Main_Gateway extends WC_Paygol_Gateway
    {
    }
}

// Add Paygol to gateway list into Woocommerce
function add_paygol_gateway($gateways)
{
    $gateways[] = 'Paygol\PaygolWoocommerce\WC_Paygol_Main_Gateway';
    return $gateways;
}

/*
 * Custom CSS and JS for this plugin
 */
function load_global_scripts_styles()
{
    // Enqueue JS
    wp_enqueue_script('paygol-js', plugin_dir_url(__FILE__) . '/assets/js/paygol.js', ['jquery'], '', false);

    // Enqueue CSS
    wp_enqueue_style('paygol-css', plugin_dir_url(__FILE__) . '/assets/css/paygol.css', [], 1.0);
}

// Create new "paygol pending" order status for payments pending in Paygol
// Based en code obtain from here: https://www.cloudways.com/blog/create-woocommerce-custom-order-status/
function register_paygol_pending_order_status()
{
    register_post_status('wc-paygol-pending', [
        'label' => 'Paygol Pending',
        'public' => true,
        'show_in_admin_status_list' => true,
        'show_in_admin_all_list' => true,
        'exclude_from_search' => false,
        'label_count' => _n_noop(
            'Paygol Pending <span class="count">(%s)</span>',
            'Paygol Pending <span class="count">(%s)</span>',
            'paygol-woocommerce'
        ),
    ]);
}

// Add new "paygol pending" status to order status list
// Based en code obtain from here: https://www.cloudways.com/blog/create-woocommerce-custom-order-status/
function add_paygol_pending_to_order_statuses($order_statuses)
{
    $new_order_statuses = [];
    foreach ($order_statuses as $key => $status) {
        $new_order_statuses[$key] = $status;
        if ('wc-pending' === $key) {
            $new_order_statuses['wc-paygol-pending'] = 'Paygol Pending';
        }
    }
    return $new_order_statuses;
}
